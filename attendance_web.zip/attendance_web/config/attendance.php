<?php

return [
    'qr_expire_minutes' => 10,
    'gps_radius_m' => 200,
];
