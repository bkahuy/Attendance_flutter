<!doctype html>
<html lang="vi">
<head>
    <meta charset="utf-8">
    <title><?php echo $__env->yieldContent('title','Dashboard'); ?> · Điểm danh TLU</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="/css/admin.css?v=<?php echo e(now()->format('His')); ?>">
    <script defer src="/js/admin.js?v=<?php echo e(now()->format('His')); ?>"></script>
    <?php echo $__env->yieldContent('head'); ?>
</head>
<body>
<div class="app">
    <?php echo $__env->make('components.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <main class="main">
        <?php echo $__env->make('components.topbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <div class="kpis"><?php echo $__env->yieldContent('kpis'); ?></div>
        <section><?php echo $__env->yieldContent('content'); ?></section>
        <div class="footer">© <?php echo e(date('Y')); ?> Điểm danh TLU · Laravel</div>
    </main>
</div>
<?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH E:\Android\Attendance_flutter\attendance_web\resources\views/layouts/app.blade.php ENDPATH**/ ?>