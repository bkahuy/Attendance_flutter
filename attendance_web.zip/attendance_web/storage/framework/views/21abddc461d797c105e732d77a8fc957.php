<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Đăng nhập – TLU</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/login.css')); ?>">
</head>
<body>
<div class="login-shell">
    <!-- Cột trái: ảnh -->
    <div class="login-hero" style="background-image:url('<?php echo e(asset('images/truongtlu.jpg')); ?>');"></div>

    <!-- Cột phải: nền tím + form -->
    <div class="login-panel">
        <div class="form-wrap">
            <div class="login-logo">
                <img src="<?php echo e(asset('images/tlu.webp')); ?>" alt="TLU" style="width:72px;height:72px;">

            </div>

            <div class="login-title">
                <h1>TLU</h1>
                <p>Chào mừng trở lại với TLU</p>
            </div>

            <?php if($errors->any()): ?>
                <div class="err">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div><?php echo e($error); ?></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>

                <div class="form-group">
                    <label class="label" for="email">Email</label>
                    <input id="email" name="email" type="email" class="input"
                           value="<?php echo e(old('email')); ?>" required autofocus autocomplete="username">
                </div>

                <div class="form-group">
                    <label class="label" for="password">Mật khẩu</label>
                    <input id="password" name="password" type="password" class="input"
                           required autocomplete="current-password">
                </div>

                <div class="row">
                    <label class="remember">
                        <input type="checkbox" name="remember"> Ghi nhớ
                    </label>
                    <?php if(Route::has('password.request')): ?>
                        <a href="<?php echo e(route('password.request')); ?>" style="color:#fff;text-decoration:underline;">Quên mật khẩu?</a>
                    <?php endif; ?>
                </div>

                <button class="btn" type="submit">ĐĂNG NHẬP</button>
            </form>
        </div>
    </div>
</div>
</body>
</html>
<?php /**PATH E:\Android\Attendance_flutter\attendance_web\resources\views/auth/login.blade.php ENDPATH**/ ?>