<?php
    $items = [
      ['href'=>route('dashboard'),                      'label'=>'Dashboard',        'icon'=>'🏠'],

      // Users list + filter theo role (query param)
      ['href'=>route('admin.users.index', ['role'=>'student']), 'label'=>'Quản lý sinh viên', 'icon'=>'🎓'],
      ['href'=>route('admin.users.index', ['role'=>'teacher']), 'label'=>'Quản lý giảng viên','icon'=>'👨‍🏫'],

      // Resource “admin/*” => tên route “admin.*.*”
      ['href'=>route('admin.courses.index'),           'label'=>'Quản lý môn học',  'icon'=>'📚'],
      ['href'=>route('admin.class-sections.index'),    'label'=>'Lớp học phần',     'icon'=>'🏫'],
      ['href'=>route('admin.schedules.index'),         'label'=>'Lịch học',         'icon'=>'📅'],

      // Báo cáo
      ['href'=>route('reports.attendance'),            'label'=>'Báo cáo điểm danh','icon'=>'📊'],
    ];
?>

<aside class="sidebar">
    <div class="brand">
        <div class="logo">TLU</div>
        <div>
            <h1>Điểm danh TLU</h1>
            <small>Hệ thống quản trị</small>
        </div>
    </div>
    <nav class="nav">
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e($it['href'] ?? '#'); ?>">
                <span><?php echo e($it['icon']); ?></span>
                <span><?php echo e($it['label']); ?></span>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <form action="<?php echo e(route('logout')); ?>" method="POST" style="margin-top:12px">
            <?php echo csrf_field(); ?>
            <button type="submit" style="all:unset;display:block;width:100%">
                <span style="display:flex;gap:10px;padding:10px 12px;border-radius:10px;background:#fff;color:#6E6AE8;font-weight:700;cursor:pointer">
                    <span>Đăng xuất</span>
            </span>
            </button>
        </form>

    </nav>
</aside>

<?php /**PATH E:\Android\Attendance_flutter\attendance_web\resources\views/components/sidebar.blade.php ENDPATH**/ ?>