<?php $__env->startSection('title','Dashboard'); ?>
<?php $__env->startSection('breadcrumbs','Dashboard'); ?>

<?php $__env->startSection('kpis'); ?>
    <div class="card">
        <h3>Sinh viên đã điểm danh hôm nay</h3>
        <div class="big"><?php echo e($stats['today_attendances'] ?? 76); ?></div>
        <div class="muted">so với hôm qua: +<?php echo e($stats['today_delta'] ?? 5); ?></div>
    </div>
    <div class="card">
        <h3>Số lớp có lịch học hôm nay</h3>
        <div class="big"><?php echo e($stats['today_classes'] ?? 8); ?></div>
    </div>
    <div class="card">
        <h3>Tỉ lệ vắng / có mặt</h3>
        <div class="big"><?php echo e($stats['presence_rate'] ?? '80%'); ?></div>
    </div>
    <div class="card">
        <h3>Top 3 lớp</h3>
        <div class="muted">64KTPM3<br>64KTPM2<br>64KHTT2</div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="section-title">
        <h2>Tình trạng điểm danh theo ngày</h2>
        <a class="btn" href="<?php echo e(route('reports.attendance')); ?>">Xem báo cáo</a>
    </div>
    <?php $__env->startComponent('components.card'); ?>
        <div style="height:220px;display:grid;place-items:center;color:var(--muted)">[Biểu đồ cột – gắn chart.js sau]</div>
    <?php echo $__env->renderComponent(); ?>

    <div class="section-title">
        <h2>Tỉ lệ điểm danh</h2>
        <span></span>
    </div>
    <?php $__env->startComponent('components.card'); ?>
        <div style="height:220px;display:grid;place-items:center;color:var(--muted)">[Biểu đồ donut – gắn chart.js sau]</div>
    <?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Android\Attendance_flutter\attendance_web\resources\views/dashboard.blade.php ENDPATH**/ ?>