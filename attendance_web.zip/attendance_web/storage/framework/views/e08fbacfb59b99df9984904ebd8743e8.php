<div class="card">
    <?php echo e($slot); ?>

</div>

<?php /**PATH E:\Android\Attendance_flutter\attendance_web\resources\views/components/card.blade.php ENDPATH**/ ?>