<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Web\AuthWebController;
use App\Http\Controllers\Admin\DashboardController;

// Guest: chỉ trang login
Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthWebController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthWebController::class, 'login'])
        ->middleware('throttle:6,1')
        ->name('login.post');
});

// Admin-only area
Route::middleware(['auth:web','role:admin'])->group(function () {
    Route::get('/dashboard', [\App\Http\Controllers\Admin\DashboardController::class, 'index'])->name('dashboard');

    Route::resource('admin/users', \App\Http\Controllers\Admin\UsersController::class);

    // (để dành bước sau)
    Route::get('admin/reports/attendance', [\App\Http\Controllers\Admin\ReportsController::class,'attendance'])->name('reports.attendance');

    Route::post('admin/class-sections/{classSection}/enroll-sync', [\App\Http\Controllers\Admin\ClassSectionsController::class,'enrollSync'])->name('class-sections.enrollSync');

    // LẤY danh sách SV đang trong lớp + SV khả dụng (chưa thuộc lớp), có tìm kiếm q
    Route::get('admin/class-sections/{classSection}/students',
        [\App\Http\Controllers\Admin\ClassSectionsController::class, 'students']
    )->name('class-sections.students');

    // SYNC danh sách SV vào lớp (nhận mảng student_ids[])
    Route::post('admin/class-sections/{classSection}/enroll-sync',
        [\App\Http\Controllers\Admin\ClassSectionsController::class, 'enrollSync']
    )->name('class-sections.enrollSync');

});


Route::post('/logout', [AuthWebController::class, 'logout'])
    ->middleware('auth:web')
    ->name('logout');

Route::get('/', fn() => redirect()->route('dashboard'));
