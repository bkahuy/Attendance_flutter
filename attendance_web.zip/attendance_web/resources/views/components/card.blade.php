<div class="card">
    {{ $slot }}
</div>

